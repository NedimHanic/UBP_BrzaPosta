CREATE database if not exists Brza_posta;

create table if not exists drzava (
	drzava_id INT auto_increment primary key,
    naziv varchar(50) not null
) ENGINE=INNODB;

create table if not exists grad (
	grad_id int auto_increment primary key,
    naziv varchar(50) not null,
    drzava_id int,
    foreign key(drzava_id) references drzava (drzava_id)
		ON UPDATE CASCADE
        ON DELETE CASCADE
);

create table if not exists lokacija (
	lokacija_id int auto_increment primary key,
    naziv_ulice VARCHAR(50) NOT NULL,
    broj INTEGER NOT NULL,
    grad_id int,
    foreign key(grad_id) references grad (grad_id)
		ON UPDATE CASCADE
        ON DELETE CASCADE
);

create table if not exists uposlenik (
	uposlenik_id int auto_increment primary key,
    ime varchar(50) not null,
    prezime varchar(50) not null,
    datum_rodjenja date not null,
    datum_zaposlenja date not null,
    plata int not null,
    lokacija_id int,
    odjel_id int,
    foreign key(lokacija_id) references lokacija (lokacija_id)
		ON UPDATE CASCADE
        ON DELETE CASCADE,
	foreign key(odjel_id) references odjel (odjel_id)
		ON UPDATE CASCADE
        ON DELETE CASCADE
);

create table if not exists odjel (
	odjel_id int auto_increment primary key,
    naziv_odjela VARCHAR(50) NOT NULL
);

create table if not exists kupac (
	kupac_id int auto_increment primary key,
    ime varchar(50) not null,
    prezime varchar(50) not null,
    broj_telefona VARCHAR(50),
    lokacija_id int,
    foreign key(lokacija_id) references lokacija (lokacija_id)
		ON UPDATE CASCADE
        ON DELETE CASCADE
);

create table if not exists skladiste (
	skladiste_id int auto_increment primary key,
    naziv varchar(50) not null,
    odgovorna_osoba_id int,
    lokacija_id int,
    foreign key(odgovorna_osoba_id) references uposlenik (uposlenik_id)
		ON UPDATE CASCADE
        ON DELETE CASCADE,
	foreign key(lokacija_id) references lokacija (lokacija_id)
		ON UPDATE CASCADE
        ON DELETE CASCADE
);

create table if not exists proizvod (
	proizvod_id int auto_increment primary key,
    naziv varchar(50) not null,
    cijena int not null,
    broj_mjeseci_garancije int,
    kolicina int not null,
    proizvodjac varchar(50) not null,
    skladiste_id int,
    foreign key(skladiste_id) references skladiste (skladiste_id)
		ON UPDATE CASCADE
        ON DELETE CASCADE
);

create table if not exists faktura (
	faktura_id int auto_increment primary key,
    iznos int not null,
    datum_kupoprodaje date not null,
    kupac_id int,
    isporuka_id int,
    foreign key(kupac_id) references kupac (kupac_id)
		ON UPDATE CASCADE
        ON DELETE CASCADE,
	foreign key(isporuka_id) references isporuka (isporuka_id)
		ON UPDATE CASCADE
        ON DELETE CASCADE
);

create table if not exists isporuka (
	isporuka_id int auto_increment primary key,
    sluzba_za_dostavu_id int,
    foreign key(sluzba_za_dostavu_id) references sluzba_za_dostavu (sluzba_za_dostavu_id)
		ON UPDATE CASCADE
        ON DELETE CASCADE
);

create table if not exists sluzba_za_dostavu (
	sluzba_za_dostavu_id int auto_increment primary key,
    broj_telefona varchar(50)
);

create table if not exists narudzba_proizvoda ( 
	narudzba_id int auto_increment primary key,
    kolicina_jednog_proizvoda int not null,
    garancija int not null,
    proizvod_id int,
    faktura_id int,
    foreign key(proizvod_id) references proizvod (proizvod_id)
		ON UPDATE CASCADE
        ON DELETE CASCADE,
	foreign key(faktura_id) references faktura (faktura_id)
		ON UPDATE CASCADE
        ON DELETE CASCADE
);

INSERT INTO drzava (naziv) VALUES ('Bosnia and Herzegovina');
INSERT INTO drzava (naziv) VALUES ('Russia');
INSERT INTO drzava (naziv) VALUES ('Ukraine');
INSERT INTO drzava (naziv) VALUES ('Netherlands');
INSERT INTO drzava (naziv) VALUES ('Portugal');
INSERT INTO drzava (naziv) VALUES ('Spain');
INSERT INTO drzava (naziv) VALUES ('Switzerland');
INSERT INTO drzava (naziv) VALUES ('Italy');
INSERT INTO drzava (naziv) VALUES ('France');
INSERT INTO drzava (naziv) VALUES ('Germany');
INSERT INTO drzava (naziv) VALUES ('Austria');
INSERT INTO drzava (naziv) VALUES ('Serbia');
INSERT INTO drzava (naziv) VALUES ('Turkey');
INSERT INTO drzava (naziv) VALUES ('Croatia');


INSERT INTO grad (naziv, drzava_id) VALUES ('Moscow',2);
INSERT INTO grad (naziv, drzava_id) VALUES ('Saint Petersburg',2);
INSERT INTO grad (naziv, drzava_id) VALUES ('Sarajevo',1);
INSERT INTO grad (naziv, drzava_id) VALUES ('Paris',9);
INSERT INTO grad (naziv, drzava_id) VALUES ('Marseille',9);
INSERT INTO grad (naziv, drzava_id) VALUES ('Rim',8);
INSERT INTO grad (naziv, drzava_id) VALUES ('Venice',8);
INSERT INTO grad (naziv, drzava_id) VALUES ('Berlin',10);
INSERT INTO grad (naziv, drzava_id) VALUES ('Barcelona',6);
INSERT INTO grad (naziv, drzava_id) VALUES ('Beograd',12);
INSERT INTO grad (naziv, drzava_id) VALUES ('Zagreb',14);
INSERT INTO grad (naziv, drzava_id) VALUES ('Dubrovnik',14);
INSERT INTO grad (naziv, drzava_id) VALUES ('Dortmund',10);
INSERT INTO grad (naziv, drzava_id) VALUES ('Istanbul',13);
INSERT INTO grad (naziv, drzava_id) VALUES ('Vienna',11);


insert into lokacija (naziv_ulice, broj, grad_id) values ('Hintze', '4953', 4);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Zmaj od Bosne', '71000', 3);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Mccormick', '82', 4);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Butmirska cesta', '18', 3);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Ilene', '61004', 1);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Via della Conciliazione', '7082', 6);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Salizade', '566', 7);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Kneza Mihaila', '999', 10);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Via del Corso', '35000', 6);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Zionskirchplatz', '61104', 8);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Village Green', '69', 9);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Loftsgordon', '96', 13);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Schmedeman', '82425', 13);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Heffernan', '1800', 15);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Bana Jelacica', '225883', 11);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Bloody Bridge', '883225', 11);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Karakol', '11', 14);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Along the Ramparts', '535', 12);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Ressam', '180', 14);
insert into lokacija (naziv_ulice, broj, grad_id) values ('Ancient streets', '450', 12);


insert into odjel (naziv_odjela) values ('Management');
insert into odjel (naziv_odjela) values ('Human Resources');
insert into odjel (naziv_odjela) values ('Warehouse department');
insert into odjel (naziv_odjela) values ('Marketing');
insert into odjel (naziv_odjela) values ('Service');


insert into uposlenik (ime, prezime, datum_rodjenja, datum_zaposlenja, plata, lokacija_id, odjel_id) values ('Demetris', 'Beyn', '1986-11-01', '2014-07-16', 1293, 5, 6);
insert into uposlenik (ime, prezime, datum_rodjenja, datum_zaposlenja, plata, lokacija_id, odjel_id) values ('Ethelbert', 'Le Quesne', '1998-08-12', '2015-02-11', 785, 8, 2);
insert into uposlenik (ime, prezime, datum_rodjenja, datum_zaposlenja, plata, lokacija_id, odjel_id) values ('Irwinn', 'Densham', '1995-07-25', '2001-04-04', 1210, 4, 4);
insert into uposlenik (ime, prezime, datum_rodjenja, datum_zaposlenja, plata, lokacija_id, odjel_id) values ('Ilhan', 'licina', '1990-03-02', '2012-11-04', 1438, 2, 3);
insert into uposlenik (ime, prezime, datum_rodjenja, datum_zaposlenja, plata, lokacija_id, odjel_id) values ('Esmir', 'Isic', '1999-09-16', '2016-01-20', 927, 2, 5);
insert into uposlenik (ime, prezime, datum_rodjenja, datum_zaposlenja, plata, lokacija_id, odjel_id) values ('Alma', 'Feriz', '1983-05-20', '2001-04-04', 553, 15, 4);
insert into uposlenik (ime, prezime, datum_rodjenja, datum_zaposlenja, plata, lokacija_id, odjel_id) values ('Ailina', 'Zanettini', '1949-06-10', '2015-10-10', 984, 10, 6);
insert into uposlenik (ime, prezime, datum_rodjenja, datum_zaposlenja, plata, lokacija_id, odjel_id) values ('Cally', 'Mannix', '1977-03-20', '2008-03-16', 609, 1, 6);
insert into uposlenik (ime, prezime, datum_rodjenja, datum_zaposlenja, plata, lokacija_id, odjel_id) values ('Zedekiah', 'De Mitris', '1960-07-24', '2012-01-01', 535, 6, 2);
insert into uposlenik (ime, prezime, datum_rodjenja, datum_zaposlenja, plata, lokacija_id, odjel_id) values ('Berina', 'Dohranovic', '1989-02-25', '2015-08-08', 547, 19, 3);
insert into uposlenik (ime, prezime, datum_rodjenja, datum_zaposlenja, plata, lokacija_id, odjel_id) values ('Inesa', 'Latifovic', '1973-10-29', '2000-09-23', 1853, 12, 5);
insert into uposlenik (ime, prezime, datum_rodjenja, datum_zaposlenja, plata, lokacija_id, odjel_id) values ('Ginger', 'Pauncefort', '1950-11-10', '2006-03-21', 1360, 11, 2);
insert into uposlenik (ime, prezime, datum_rodjenja, datum_zaposlenja, plata, lokacija_id, odjel_id) values ('Raimondo', 'Phripp', '1981-05-13', '2006-07-12', 1000, 5, 5);
insert into uposlenik (ime, prezime, datum_rodjenja, datum_zaposlenja, plata, lokacija_id, odjel_id) values ('Kenan', 'Solo', '1969-04-14', '2012-01-15', 847, 26, 3);


insert into kupac (ime, prezime, broj_telefona) values ('Peter', 'Lee', '638-408-1351');
insert into kupac (ime, prezime, broj_telefona) values ('Joe', 'Kim', '941-982-5478');
insert into kupac (ime, prezime, broj_telefona) values ('David', 'Letty', '809-262-7155');
insert into kupac (ime, prezime, broj_telefona) values ('Emir', 'Isic', '538-321-9473');
insert into kupac (ime, prezime, broj_telefona) values ('Izet', 'Fazlinovic', '566-351-9753');
insert into kupac (ime, prezime, broj_telefona) values ('John', 'Mfume', '378-758-7651');
insert into kupac (ime, prezime, broj_telefona) values ('Haley', 'Martinez', '202-664-6169');
insert into kupac (ime, prezime, broj_telefona) values ('Enis', 'Beslagic', '153-967-4410');


insert into sluzba_za_dostavu (broj_telefona) values ('413-203-0203');
insert into sluzba_za_dostavu (broj_telefona) values ('715-357-4220');
insert into sluzba_za_dostavu (broj_telefona) values ('949-754-2289');
insert into sluzba_za_dostavu (broj_telefona) values ('836-476-7384');
insert into sluzba_za_dostavu (broj_telefona) values ('334-993-3933');


insert into isporuka (sluzba_za_dostavu_id) values (2);
insert into isporuka (sluzba_za_dostavu_id) values (3);
insert into isporuka (sluzba_za_dostavu_id) values (5);
insert into isporuka (sluzba_za_dostavu_id) values (5);
insert into isporuka (sluzba_za_dostavu_id) values (1);
insert into isporuka (sluzba_za_dostavu_id) values (3);
insert into isporuka (sluzba_za_dostavu_id) values (3);
insert into isporuka (sluzba_za_dostavu_id) values (4);


insert into faktura (iznos, datum_kupoprodaje, kupac_id, isporuka_id) values (248, '2018-07-07', 2,4);
insert into faktura (iznos, datum_kupoprodaje, kupac_id, isporuka_id) values (955, '2015-04-03', 1, 7);
insert into faktura (iznos, datum_kupoprodaje, kupac_id, isporuka_id) values (449, '2003-01-12', 7, 5);
insert into faktura (iznos, datum_kupoprodaje, kupac_id, isporuka_id) values (137, '2016-09-22', 6, 3);
insert into faktura (iznos, datum_kupoprodaje, kupac_id, isporuka_id) values (496, '2016-03-29', 8, 3);
insert into faktura (iznos, datum_kupoprodaje, kupac_id, isporuka_id) values (597, '2012-08-27', 5, 6);
insert into faktura (iznos, datum_kupoprodaje, kupac_id, isporuka_id) values (940, '2013-12-17', 6, 1);
insert into faktura (iznos, datum_kupoprodaje, kupac_id, isporuka_id) values (37, '2013-09-06', 7, 1);
insert into faktura (iznos, datum_kupoprodaje, kupac_id, isporuka_id) values (245, '2002-11-24', 1, 6);
insert into faktura (iznos, datum_kupoprodaje, kupac_id, isporuka_id) values (206, '2010-05-13', 3, 3);


insert into proizvod (naziv, cijena, broj_mjeseci_garancije, kolicina, proizvodjac, skladiste_id) values ('CD-R', 10, null, 17, 'sohu', 2);
insert into proizvod (naziv, cijena, broj_mjeseci_garancije, kolicina, proizvodjac, skladiste_id) values ('CD-RW', 15, null, 26, 'sohu', 10);
insert into proizvod (naziv, cijena, broj_mjeseci_garancije, kolicina, proizvodjac, skladiste_id) values ('LED monitor', 581, 12, 56, 'ning', 5);
insert into proizvod (naziv, cijena, broj_mjeseci_garancije, kolicina, proizvodjac, skladiste_id) values ('LCD', 481, 12, 71, 'ning', 8);
insert into proizvod (naziv, cijena, broj_mjeseci_garancije, kolicina, proizvodjac, skladiste_id) values ('Ergonomic keyboard', 339, 6, 54, 'lycos', 8);
insert into proizvod (naziv, cijena, broj_mjeseci_garancije, kolicina, proizvodjac, skladiste_id) values ('Wireless keyboard', 539, 6, 7, 'instagram', 6);
insert into proizvod (naziv, cijena, broj_mjeseci_garancije, kolicina, proizvodjac, skladiste_id) values ('Sound card', 163, 10, 59, 'columbia', 1);
insert into proizvod (naziv, cijena, broj_mjeseci_garancije, kolicina, proizvodjac, skladiste_id) values ('Graphics card', 213, 10, 46, 'cocolog-nifty', 5);
insert into proizvod (naziv, cijena, broj_mjeseci_garancije, kolicina, proizvodjac, skladiste_id) values ('Wireless mouse', 86, 6, 78, 'columbia', 7);
insert into proizvod (naziv, cijena, broj_mjeseci_garancije, kolicina, proizvodjac, skladiste_id) values ('Optical mouse', 123, 6, 5, 'lycos', 3);
insert into proizvod (naziv, cijena, broj_mjeseci_garancije, kolicina, proizvodjac, skladiste_id) values ('Laser mouse', 254, 6, 10, 'twitter', 9);
insert into proizvod (naziv, cijena, broj_mjeseci_garancije, kolicina, proizvodjac, skladiste_id) values ('CPU', 779, 24, 18, 'ning', 2);
insert into proizvod (naziv, cijena, broj_mjeseci_garancije, kolicina, proizvodjac, skladiste_id) values ('Laser printer', 651, 12, 23, 'ning', 4);


insert into skladiste (naziv, odgovorna_osoba_id, lokacija_id) values ('Bosna', 2, 1);
insert into skladiste (naziv, odgovorna_osoba_id, lokacija_id) values ('Una', 2, 2);
insert into skladiste (naziv, odgovorna_osoba_id, lokacija_id) values ('Sava', 5, 3);
insert into skladiste (naziv, odgovorna_osoba_id, lokacija_id) values ('Sana', 8, 4);
insert into skladiste (naziv, odgovorna_osoba_id, lokacija_id) values ('Drina', 8, 5);
insert into skladiste (naziv, odgovorna_osoba_id, lokacija_id) values ('Neretva', 3, 6);
insert into skladiste (naziv, odgovorna_osoba_id, lokacija_id) values ('Zeljeznica', 4, 7);
insert into skladiste (naziv, odgovorna_osoba_id, lokacija_id) values ('Miljacka', 5, 8);
insert into skladiste (naziv, odgovorna_osoba_id, lokacija_id) values ('Usora', 4, 9);
insert into skladiste (naziv, odgovorna_osoba_id, lokacija_id) values ('Vrbas', 3, 10);


insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (14, 12, 1, 1);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (14, 3, 2, 2);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (12, 3, 3, 3);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (3, 3, 4, 4);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (7, 6, 5, 5);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (10, 6, 6, 6);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (3, 24, 7, 7);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (6, 2, 8, 8);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (1, 12, 9, 9);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (3, 12, 10, 10);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (6, 3, 11, 10);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (15, 5, 12, 9);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (8, 24, 13, 8);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (7, 3, 5, 7);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (9, 6, 6, 6);
insert into narudzba_proizvoda (kolicina_jednog_proizvoda, garancija, proizvod_id, faktura_id) values (12, 12, 7, 5);